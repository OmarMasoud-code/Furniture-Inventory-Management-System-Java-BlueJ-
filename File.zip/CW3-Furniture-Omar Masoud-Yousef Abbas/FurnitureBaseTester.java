import java.util.*;

public class FurnitureBaseTester {
    public static void main(String[] args) {
        // Creating instances of FurnitureBase for testing
        FurnitureBase furniture1 = new FurnitureBase(1, "Dining Table", "Table", "Wood", "40x40x30", 150.00);
        FurnitureBase furniture2 = new FurnitureBase(1, "Comfortable Chair", "Chair", "Wood", "30x30x40", 99.99);

        // Displaying information about the furniture
        displayFurnitureDetails(furniture1);
        displayFurnitureDetails(furniture2);

        // Testing the  functionality
        testCoreFunctionality(furniture1);
        testCoreFunctionality(furniture2);
    }

    private static void displayFurnitureDetails(FurnitureBase furniture) {
        System.out.println("Furniture ID: " + furniture.getFurId());
        System.out.println("Description: " + furniture.getDescription());
        System.out.println("Category: " + furniture.getCategory());
        System.out.println("Materials: " + furniture.getMaterials());
        System.out.println("Dimensions: " + furniture.getDimensions());
        System.out.println("Price: $" + furniture.getPrice());
        System.out.println();
    }
    
    //the method to perform testing
    private static void testCoreFunctionality(FurnitureBase furniture) {
        furniture.setFurId(3);
        furniture.setDescription("Elegant Bed");
        furniture.setCategory("Bed");
        furniture.setMaterials("Metal");
        furniture.setDimensions("60x80x40");
        furniture.setPrice(299.99);
        System.out.println("Updated Furniture Details:");
        displayFurnitureDetails(furniture);
    }
}

