/**
 * OfficeFurniture represents a specialized subset of furniture items within the FurnitureStore system.
 * This type of furniture is tailored for use in office environments, be it home offices, corporate settings,
 * or other professional areas. Each OfficeFurniture item might possess attributes like ergonomic design,
 * adjustability features, durability specifications, and more. Examples include office chairs, desks,
 * conference tables, file cabinets, and partitions.
 * 
 * The distinction of OfficeFurniture is crucial as these items prioritize functionality, comfort, and
 * durability for long working hours. They play a pivotal role in ensuring a conducive and productive work environment.
 * Furthermore, this classification helps in streamlining product recommendations for businesses and professionals 
 * and enables the store to target specific marketing and sales strategies towards corporate clients or remote workers.
 */
public class OfficeFurniture extends FurnitureBase {
    private String furnitureCategory;
    private boolean isErgonomic;
    
    // Constructor
    public OfficeFurniture(int furId, String description, String category, String materials, String dimensions, double price,
                        FurnitureCategory supplier, String furnitureCategory, boolean isErgonomic) {
        super(furId, description, category, materials, dimensions, price);
        this.furnitureCategory = furnitureCategory;
        this.isErgonomic = isErgonomic;
        adjustPrice();
    }
    // Getters
    public String getFurnitureCategory() {
        return furnitureCategory;
    }

    public boolean isErgonomicFurniture() {
        return isErgonomic;
    }

    // Implementing the adjustPrice method
    @Override
    public void adjustPrice() {
        if (isErgonomic) {
            double ergonomicPriceIncrease = getPrice() * 0.10;
            setPrice(getPrice() + ergonomicPriceIncrease);
        }
        switch (getMaterials()) {
            case "Wood":
                double woodPriceIncrease = getPrice() * 0.15;
                setPrice(getPrice() + woodPriceIncrease);
                break;
            case "Metal":
                double metalPriceIncrease = getPrice() * 0.05;
                setPrice(getPrice() + metalPriceIncrease);
                break;
        }
    }

}


