import java.util.Scanner;
import java.util.List;

public class Tester {
    ///the method for doing all the tests
    public void doTest() {
        FURNITUREInterface homeFurnishingsDepot = new FurnitureStore("Home Furnishings Depot", "123 Furniture Street");
        Scanner scanner = new Scanner(System.in);

        // Test: Adding furniture
        System.out.println("Test 1: Adding furniture");
        FurnitureBase chair = new FurnitureBase(1, "Comfortable Chair", "Chair", "Wood", "30x30x40", 99.99);
        FurnitureBase table = new FurnitureBase(2, "Sturdy Table", "Table", "Metal", "40x40x30", 149.99);
        homeFurnishingsDepot.addFurniture(chair);
        homeFurnishingsDepot.addFurniture(table);
        System.out.println("Furniture added successfully.");

        // Test: Adding purchaser
        System.out.println("Test 2: Adding purchaser");
        Purchaser customer1 = new Purchaser("JohnDoe", "John Doe", "Chair");
        Purchaser customer2 = new Purchaser("JaneSmith", "Jane Smith", "Table");
        homeFurnishingsDepot.addPurchaser(customer1);
        homeFurnishingsDepot.addPurchaser(customer2);
        System.out.println("Purchasers added successfully.");

        // Test: Adding category
        System.out.println("Test 3: Adding category");
        FurnitureCategory sofaCategory = new FurnitureCategory("Sofa", "Comfortable seating for your living room", 200.0, false, customer1);
        FurnitureCategory tableCategory = new FurnitureCategory("Table", "Sturdy tables for various uses", 100.0, true, customer2);
        homeFurnishingsDepot.addCategory(sofaCategory);
        homeFurnishingsDepot.addCategory(tableCategory);
        System.out.println("Categories added successfully.");

        // Test: View furniture details
        System.out.println("Test 4: View furniture details");
        System.out.print("Enter furniture ID to view details: ");
        int furnitureId = scanner.nextInt();
        FurnitureBase viewedFurniture = homeFurnishingsDepot.getFurnitureByID(furnitureId);
        if (viewedFurniture != null) {
            System.out.println("Details for Furniture ID " + furnitureId + ":");
            System.out.println(viewedFurniture.toString());
        } else {
            System.out.println("Furniture not found.");
        }

        // Test: View purchaser details
        System.out.println("Test 5: View purchaser details");
        System.out.print("Enter purchaser ID to view details: ");
        int purchaserId = scanner.nextInt();
        Purchaser viewedPurchaser = homeFurnishingsDepot.getPurchaserByID(purchaserId);
        if (viewedPurchaser != null) {
            System.out.println("Details for Purchaser ID " + purchaserId + ":");
            System.out.println(viewedPurchaser.toString());
        } else {
            System.out.println("Purchaser not found.");
        }

        // Test: View category details
        System.out.println("Test 6: View category details");
        System.out.print("Enter category ID to view details: ");
        int categoryId = scanner.nextInt();
        FurnitureCategory viewedCategory = homeFurnishingsDepot.getCategoryByID(categoryId);
        if (viewedCategory != null) {
            System.out.println("Details for Category ID " + categoryId + ":");
            System.out.println(viewedCategory.toString());
        } else {
            System.out.println("Category not found.");
        }

    }

    public static void main(String[] args) {
        Tester tester = new Tester();
        tester.doTest();
    }
}




