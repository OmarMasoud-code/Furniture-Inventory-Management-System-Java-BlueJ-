import java.util.*;

public class Purchaser {
    private String id;
    private String name;
    private String furnitureType;
    private String contactDetails;
    private Date purchaseDate;
    private List<String> purchaseHistory;

    // Constructor
    public Purchaser(String id, String name, String furnitureType) {
        this.id = id;
        this.name = name;
        this.furnitureType = furnitureType;
        this.purchaseDate = new Date();
        this.purchaseHistory = new ArrayList<>();
    }

    public Purchaser(String id, String name, String furnitureType, String contactDetails, Date purchaseDate) {
        this.id = id;
        this.name = name;
        this.furnitureType = furnitureType;
        this.contactDetails = contactDetails;
        this.purchaseDate = purchaseDate;
        this.purchaseHistory = new ArrayList<>();
    }
    
    private FurnitureBase purchasedFurniture;

    public void setPurchasedFurniture(FurnitureBase purchasedFurniture) {
        this.purchasedFurniture = purchasedFurniture;
    }

    // Getters and Setters
    public String getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFurnitureType() {
        return furnitureType;
    }

    public String getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(String contactDetails) {
        this.contactDetails = contactDetails;
    }

    public List<String> getPurchaseHistory() {
        return purchaseHistory;
    }

    // Methods
    public void addToPurchaseHistory(String item) {
        purchaseHistory.add(item);
    }

    public boolean isPurchaseValid(int THRESHOLD_VALUE) {
        return purchaseHistory.size() < THRESHOLD_VALUE;
    }

    public static Purchaser createJohnDoe() {
        return new Purchaser("JD001", "John Doe", "Sofa", "1234567890", new Date());
    }

    public static Purchaser createJaneSmith() {
        return new Purchaser("JS001", "Jane Smith", "Table", "9876543210", new Date());
    }
}
