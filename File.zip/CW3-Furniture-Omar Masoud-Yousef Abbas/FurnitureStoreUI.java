import java.util.Scanner;
import java.util.List;

public class FurnitureStoreUI {
    private Scanner reader = new Scanner(System.in);
    private FURNITUREInterface store = new FurnitureStore("Fortune Furnitures", "Downtown");


    public void runUI() {
        int choice = getOption();
        
        while (choice != 0) {
            switch (choice) {
                case 1:
                    addFurniture();
                    break;
                case 2:
                    addPurchaser();
                    break;
                case 3:
                    addCategory();
                    break;
                case 4:
                    viewFurniture();
                    break;
                case 5:
                    viewPurchaser();
                    break;
                case 6:
                    viewCategory();
                    break;
                case 7:
                    purchaseFurniture();
                    break;
                case 8:
                    displayPurchaseHistory();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

            // output menu & get choice
            choice = getOption();
        }
        System.out.println("\nThank you for using Fortune Furnitures System.");
    }

    private int getOption() {
        System.out.println("\nWhat would you like to do?");
        System.out.println("0. Quit");
        System.out.println("1. Add furniture");
        System.out.println("2. Add purchaser");
        System.out.println("3. Add category");
        System.out.println("4. View furniture details by ID");
        System.out.println("5. View purchaser details by ID");
        System.out.println("6. View category details by ID");
        System.out.println("7. Purchase furniture");
        System.out.println("8. Display purchase history");
        System.out.print("Enter your choice: ");

        // read the choice
        int option = reader.nextInt();
        reader.nextLine();
        return option;
    }

    private void addFurniture() {
        System.out.println("Enter furniture details:");
        
        System.out.print("Enter furniture ID: ");
        int furId = reader.nextInt();
        reader.nextLine();
        
        System.out.print("Enter furniture name: ");
        String furName = reader.nextLine();
        
        System.out.print("Enter furniture type: ");
        String furType = reader.nextLine();
        
        System.out.print("Enter furniture material: ");
        String furMaterial = reader.nextLine();
        
        System.out.print("Enter furniture dimensions: ");
        String furDimensions = reader.nextLine();
        
        System.out.print("Enter furniture price: ");
        double furPrice = reader.nextDouble();
        
        FurnitureBase furniture = new FurnitureBase(furId, furName, furType, furMaterial, furDimensions, furPrice);
        store.addFurniture(furniture);
        System.out.println("Furniture added successfully.");
    }

    private void addPurchaser() {
        System.out.println("Enter purchaser details:");
    
        System.out.print("Enter purchaser ID: ");
        String purchaserId = reader.nextLine();
        
        System.out.print("Enter purchaser name: ");
        String purchaserName = reader.nextLine();
        
        System.out.print("Enter furniture type: ");
        String furnitureType = reader.nextLine();
        
        Purchaser purchaser = new Purchaser(purchaserId, purchaserName, furnitureType);
        store.addPurchaser(purchaser);
        System.out.println("Purchaser added successfully.");
    }

    private void addCategory() {
        System.out.println("Enter category details:");
    
        System.out.print("Enter category ID: ");
        String categoryId = reader.nextLine();
        
        System.out.print("Enter category name: ");
        String categoryName = reader.nextLine();
        
        System.out.print("Enter maximum load: ");
        double maxLoad = reader.nextDouble();
        
        System.out.print("Is outdoor? (true/false): ");
        boolean isOutdoor = reader.nextBoolean();
        
        FurnitureCategory category = new FurnitureCategory(categoryId, categoryName, maxLoad, isOutdoor, null);
        store.addCategory(category);
        System.out.println("Category added successfully.");
    }

    private void viewFurniture() {
        System.out.print("Enter furniture ID: ");
        int id = reader.nextInt();
        reader.nextLine();
        FurnitureBase furniture = store.getFurnitureByID(id);
        if (furniture != null) {
            System.out.println("\nFurniture Details:");
            System.out.println(furniture);
        } else {
            System.out.println("Furniture not found.");
        }
    }

    private void viewPurchaser() {
        System.out.print("Enter purchaser ID: ");
        int id = reader.nextInt();
        reader.nextLine();
        Purchaser purchaser = store.getPurchaserByID(id);
        if (purchaser != null) {
            System.out.println("\nPurchaser Details:");
            System.out.println(purchaser);
        } else {
            System.out.println("Purchaser not found.");
        }
    }

    private void viewCategory() {
        System.out.print("Enter category ID: ");
        int id = reader.nextInt();
        reader.nextLine();
        FurnitureCategory category = store.getCategoryByID(id);
        if (category != null) {
            System.out.println("\nCategory Details:");
            System.out.println(category);
        } else {
            System.out.println("Category not found.");
        }
    }

    private void purchaseFurniture() {
        System.out.print("Enter purchaser ID: ");
        int purchaserId = reader.nextInt();
        reader.nextLine();
        System.out.print("Enter furniture ID to purchase: ");
        int furnitureId = reader.nextInt();
        reader.nextLine();
    
        Purchaser purchaser = store.getPurchaserByID(purchaserId);
        FurnitureBase furniture = store.getFurnitureByID(furnitureId);
    
        if (purchaser != null && furniture != null) {
            purchaser.addToPurchaseHistory(furniture.getType());
            furniture.addOrder(purchaser);
    
            System.out.println("Purchase successful.");
        } else {
            System.out.println("Invalid purchaser or furniture ID. Purchase failed.");
        }

    }

    private void displayPurchaseHistory() {
        System.out.print("Enter purchaser ID: ");
        int purchaserId = reader.nextInt();
        reader.nextLine();
    
        Purchaser purchaser = store.getPurchaserByID(purchaserId);
    
        if (purchaser != null) {
            List<String> purchaseHistory = purchaser.getPurchaseHistory();
            System.out.println("Purchase history for Purchaser ID " + purchaserId + ":");
            
            for (String item : purchaseHistory) {
                System.out.println(item);
            }
        } else {
            System.out.println("Purchaser not found.");
        }
    }

    public static void main(String[] args) {
        FurnitureStoreUI ui = new FurnitureStoreUI();
        ui.runUI();
    }
}


