import java.util.ArrayList;
import java.util.List;

public class FurnitureCategory {
    private String id;
    private String typeName;
    private Double maximumLoad;
    private Boolean isOutdoor;
    private Purchaser recentPurchaser;
    private List<String> materials;

    // Constructor
    public FurnitureCategory(String id, String typeName, Double maximumLoad,
                             Boolean isOutdoor, Purchaser recentPurchaser) {
        this.id = id;
        this.typeName = typeName;
        this.maximumLoad = maximumLoad;
        this.isOutdoor = isOutdoor;
        this.recentPurchaser = recentPurchaser;
        this.materials = new ArrayList<>();
    }

    // Getters
    public String getID() {
        return id;
    }

    public String getTypeName() {
        return typeName;
    }

    public Double getMaxLoad() {
        return maximumLoad;
    }

    public Purchaser getRecentPurchaser() {
        return recentPurchaser;
    }

    public List<String> getMaterials() {
        return materials;
    }

    // Getter for room recommendation
    public String getRoomRecommendation() {
        switch (typeName.toLowerCase()) {
            case "sofa":
                return "Living Room";
            case "table":
                return "Dining Room";
            case "chair":
                return "Study Room";
            default:
                return "General Room";
        }
    }

    // method to add a new material to the materials list
    public void addMaterial(String material) {
        materials.add(material);
    }

    // method to check if the furniture type is suitable for outdoor placement
    public Boolean isSuitableForOutdoor() {
        return isOutdoor && (maximumLoad > 50.0);
    }

    public static FurnitureCategory createSofaCategory() {
        Purchaser johnDoe = Purchaser.createJohnDoe();
        return new FurnitureCategory("SofaID", "Sofa", 200.0, false, johnDoe);
    }

    public static FurnitureCategory createTableCategory() {
        Purchaser janeSmith = Purchaser.createJaneSmith();
        return new FurnitureCategory("TableID", "Table", 100.0, true, janeSmith);
    }
}


