import java.util.*;

public class FurnitureBase {
    private int furId;
    private String description;
    private String category;
    private String materials;
    private String dimensions;
    private String type;
    private double price;
    private FurnitureCategory supplier;
    private List<Purchaser> orders;
    
    
    // Constructor
    public FurnitureBase(int furId, String description, String category, String materials, String dimensions, double price) {
        this.furId = furId;
        this.description = description;
        this.category = category;
        this.materials = materials;
        this.dimensions = dimensions;
        this.price = price;
        this.type = type;
        this.orders = new ArrayList<>();
    }

    // Methods (getters and setters)
    public int getFurId() {
        return furId;
    }

    public void setFurId(int furId) {
        this.furId = furId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMaterials() {
        return materials;
    }

    public void setMaterials(String materials) {
        this.materials = materials;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    public FurnitureCategory getSupplier() {
        return supplier;
    }
    
    public void setSupplier(FurnitureCategory supplier) {
        this.supplier = supplier;
    }
    
    public List<Purchaser> getOrders() {
        return orders;
    }
    
    public String getType() {
        return type;
    }

    public void addOrder(Purchaser order) {
        if (orders == null) {
            orders = new ArrayList<>();
        }
        orders.add(order);
    }
    
    public void adjustPrice() {
        
    }
    
}


