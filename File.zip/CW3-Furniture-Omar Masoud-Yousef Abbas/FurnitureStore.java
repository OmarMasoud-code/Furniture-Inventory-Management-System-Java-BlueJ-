import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class FurnitureStore implements FURNITUREInterface {
    private String storeName;
    private String location;
    private List<FurnitureBase> furnitureItems;
    private List<Purchaser> customerOrders;
    private List<FurnitureCategory> suppliers;

    // Constructor
    public FurnitureStore(String storeName, String location) {
        this.storeName = storeName;
        this.location = location;
        this.furnitureItems = new ArrayList<>();
        this.customerOrders = new ArrayList<>();
        this.suppliers = new ArrayList<>();

        loadFurnitureAndSuppliers();
        loadOrders();
        linkOrdersToFurniture();
    }

    // Implementation of the methods from FURNITURE interface
    @Override
    public void addFurniture(FurnitureBase furniture) {
        furnitureItems.add(furniture);
    }

    @Override
    public void addPurchaser(Purchaser purchaser) {
        customerOrders.add(purchaser);
    }

    @Override
    public void addCategory(FurnitureCategory category) {
        suppliers.add(category);
    }

    @Override
    public FurnitureBase getFurnitureByID(int id) {
        return retrieveFurniture(id);
    }

    @Override
    public Purchaser getPurchaserByID(int id) {
        return retrievePurchaser(id);
    }

    @Override
    public FurnitureCategory getCategoryByID(int id) {
        return retrieveCategory(id);
    }


    private void loadFurnitureAndSuppliers() {
        // Furniture Items
        FurnitureBase chair = new FurnitureBase(0, "Comfortable Chair", "Chair", "Wood", "30x30x40", 99.99);
        FurnitureBase table = new FurnitureBase(1, "Sturdy Table", "Table", "Metal", "40x40x30", 149.99);
        furnitureItems.add(chair);
        furnitureItems.add(table);

        // Suppliers (Furniture Categories)
        FurnitureCategory sofaCategory = new FurnitureCategory("SofaID", "Sofa", 200.0, false, null);
        FurnitureCategory tableCategory = new FurnitureCategory("TableID", "Table", 100.0, true, null);
        suppliers.add(sofaCategory);
        suppliers.add(tableCategory);

        chair.setSupplier(sofaCategory);
        table.setSupplier(tableCategory);
    }
    
    //loading orders
    private void loadOrders() {
        Purchaser customer1 = new Purchaser("JD001", "John Doe", "Sofa", "123 Main St", new Date());
        Purchaser customer2 = new Purchaser("JS001", "Jane Smith", "Table", "456 Oak St", new Date());

        customerOrders.add(customer1);
        customerOrders.add(customer2);
    }

    //method to return furniture by the ID
    private FurnitureBase retrieveFurniture(int id) {
        for (FurnitureBase furniture : furnitureItems) {
            if (furniture.getFurId() == id) {
                return furniture;
            }
        }
        return null;
    }
    
    
    //method to return the purchaser by ID
    private Purchaser retrievePurchaser(int id) {
        for (Purchaser purchaser : customerOrders) {
            if (purchaser.getID().equals(Integer.toString(id))) {
                return purchaser;
            }
        }
        return null;
        }
    
    //method to return the furniture category by ID
    private FurnitureCategory retrieveCategory(int id) {
        for (FurnitureCategory category : suppliers) {
            if (category.getID().equals(Integer.toString(id))) {
                return category;
            }
        }
        return null;
    }

    //method that links the orders to the furniture
    private void linkOrdersToFurniture() {
        for (Purchaser purchaser : customerOrders) {
            FurnitureBase purchasedFurniture = retrieveFurnitureByCategory(purchaser.getFurnitureType());
            purchaser.setPurchasedFurniture(purchasedFurniture);
        }
    }

    //method to get the furniture by category
    private FurnitureBase retrieveFurnitureByCategory(String category) {
        for (FurnitureBase furniture : furnitureItems) {
            if (furniture.getCategory().equals(category)) {
                return furniture;
            }
        }
        return null;
    }
    
}

